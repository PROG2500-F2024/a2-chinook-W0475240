# PROG2500-A2-Chinook

Project Template: 
  WPF Application targeting .Net 7.0 and Windows 10.0.17763.0

Packages Installed:
  Microsoft.EntityFrameworkCore (v7.0.3)
  Microsoft.EntityFrameworkCore.Design (v7.0.3)
  Microsoft.EntityFrameworkCore.Tools (v7.0.3)
