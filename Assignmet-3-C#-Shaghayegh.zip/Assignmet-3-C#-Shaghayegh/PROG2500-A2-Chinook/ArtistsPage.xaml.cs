﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using ChinookWPFApp.Models;

namespace ChinookWPFApp
{
    public partial class ArtistsPage : INotifyPropertyChanged
    {
        private Artist _selectedArtist;
        private List<Artist> _allArtists;

        public event PropertyChangedEventHandler PropertyChanged;

        public ArtistsPage()
        {
            InitializeComponent();
            DataContext = this;
            LoadArtists();
        }

        public List<Artist> Artists { get; set; }

        public Artist SelectedArtist
        {
            get { return _selectedArtist; }
            set
            {
                _selectedArtist = value;
                OnPropertyChanged();
            }
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void LoadArtists()
        {
            using (var context = new ChinookContext())
            {
                Artists = context.Artists.ToList();
                _allArtists = Artists;
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                Artists = _allArtists;
            }
            else
            {
                Artists = _allArtists.Where(a => a.Name.ToLower().Contains(SearchBox.Text.ToLower())).ToList();
            }
            OnPropertyChanged(nameof(Artists));
        }
    }
}
