﻿using ChinookWPFApp.Models;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ChinookWPFApp
{
    public partial class OrdersPage : Page, INotifyPropertyChanged
    {
        private ChinookContext _context = new ChinookContext();
        private ObservableCollection<Customer> _customers;
        private ObservableCollection<Invoice> _invoices;
        private Invoice _selectedInvoice; // New property to store the selected invoice
        private int _totalTracks; // New property to store the total tracks for the selected invoice

        public ObservableCollection<Customer> Customers
        {
            get { return _customers; }
            set
            {
                _customers = value;
                OnPropertyChanged("Customers");
                OnPropertyChanged("CustomerCount");
            }
        }

        public ObservableCollection<Invoice> Invoices
        {
            get { return _invoices; }
            set
            {
                _invoices = value;
                OnPropertyChanged("Invoices");
            }
        }

        public int CustomerCount
        {
            get { return Customers?.Count() ?? 0; }
        }

        public Invoice SelectedInvoice
        {
            get { return _selectedInvoice; }
            set
            {
                _selectedInvoice = value;
                OnPropertyChanged("SelectedInvoice");
                UpdateTotalTracks(); // Call method to update total tracks when selected invoice changes
            }
        }

        public int TotalTracks
        {
            get { return _totalTracks; }
            set
            {
                _totalTracks = value;
                OnPropertyChanged("TotalTracks");
            }
        }

        public OrdersPage()
        {
            InitializeComponent();
            DataContext = this;
            Customers = new ObservableCollection<Customer>(_context.Customers.ToList());
            Invoices = new ObservableCollection<Invoice>(_context.Invoices.ToList());
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchText = SearchBox.Text.ToLower();
            Customers = new ObservableCollection<Customer>(_context.Customers
                .Where(c => string.IsNullOrEmpty(searchText) ||
                            c.FirstName.ToLower().Contains(searchText) ||
                            c.LastName.ToLower().Contains(searchText))
                .OrderBy(c => c.LastName)
                .ThenBy(c => c.FirstName)
                .ToList());
        }

        private void UpdateTotalTracks()
        {
            if (SelectedInvoice != null)
            {
                // Calculate total tracks for the selected invoice
                TotalTracks = SelectedInvoice.InvoiceLines.Sum(il => il.Quantity);
            }
            else
            {
                TotalTracks = 0; // If no invoice is selected, set total tracks to 0
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
