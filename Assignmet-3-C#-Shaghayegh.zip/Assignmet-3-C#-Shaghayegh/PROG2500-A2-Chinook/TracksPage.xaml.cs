﻿using ChinookWPFApp.Models;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ChinookWPFApp
{
    public partial class TracksPage : Page, INotifyPropertyChanged
    {
        public TracksPage()
        {
            InitializeComponent();
            DataContext = this;
            LoadData();
        }

        private List<Track> _tracks;

        public List<Track> Tracks
        {
            get { return _tracks; }
            set
            {
                _tracks = value;
                OnPropertyChanged("Tracks");
            }
        }

        private void LoadData()
        {
            using (var context = new ChinookContext())
            {
                Tracks = context.Tracks.ToList();
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchTerm = SearchBox.Text.ToLower();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                using (var context = new ChinookContext())
                {
                    Tracks = context.Tracks.Where(t => t.Name.ToLower().Contains(searchTerm)).ToList();
                }
            }
            else
            {
                LoadData();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
