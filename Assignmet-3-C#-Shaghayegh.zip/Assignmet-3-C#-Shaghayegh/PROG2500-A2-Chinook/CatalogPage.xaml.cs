﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Controls;
using System.Collections.Generic;
using System.Windows;
using ChinookWPFApp.Models;

namespace ChinookWPFApp
{
    public partial class CatalogPage : Page, INotifyPropertyChanged
    {
        private List<CatalogItem> _allCatalog;
        private int _itemCount;
        private ObservableCollection<IGrouping<string, CatalogItem>> _artistGroups;

        public ObservableCollection<IGrouping<string, CatalogItem>> ArtistGroups
        {
            get { return _artistGroups; }
            set
            {
                _artistGroups = value;
                OnPropertyChanged();
            }
        }

        public CatalogPage()
        {
            InitializeComponent();

            DataContext = this;

            // Load data for all artists
            using (var db = new ChinookContext())
            {
                var catalog = db.Artists
                    .OrderBy(a => a.Name)
                    .Select(a => new CatalogItem
                    {
                        ArtistId = a.ArtistId,
                        Name = a.Name,
                        Albums = a.Albums
                            .Select(al => new AlbumItem
                            {
                                AlbumId = al.AlbumId,
                                Title = al.Title,
                                Tracks = al.Tracks
                                    .Select(t => new TrackItem
                                    {
                                        TrackId = t.TrackId,
                                        Name = t.Name,
                                        Genre = t.Genre.Name
                                    })
                                    .OrderBy(t => t.Name)
                                    .ToList()
                            })
                            .OrderBy(al => al.Title)
                            .ToList()
                    })
                    .ToList();

                _allCatalog = catalog;
                ArtistGroups = new ObservableCollection<IGrouping<string, CatalogItem>>(_allCatalog.GroupBy(c => c.Name[0].ToString()));

                // Set up the data binding for the main list box
                CatalogList.ItemsSource = _allCatalog;
                ItemCount = _allCatalog.Count;
            }
        }

        // Rest of the code remains the same

        public int ItemCount
        {
            get { return _itemCount; }
            set
            {
                if (_itemCount != value)
                {
                    _itemCount = value;
                    OnPropertyChanged();
                }
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                CatalogList.ItemsSource = _allCatalog;
                ItemCount = _allCatalog.Count;
                ArtistGroups = new ObservableCollection<IGrouping<string, CatalogItem>>(_allCatalog.GroupBy(c => c.Name[0].ToString()));
            }
            else
            {
                var searchKeyword = SearchBox.Text.ToLower();
                var filteredCatalog = _allCatalog.Where(a => a.Name.ToLower().Contains(searchKeyword)).ToList();
                ItemCount = filteredCatalog.Count;
                CatalogList.ItemsSource = filteredCatalog;
                ArtistGroups = new ObservableCollection<IGrouping<string, CatalogItem>>(filteredCatalog.GroupBy(c => c.Name[0].ToString()));
            }
            OnPropertyChanged(nameof(CatalogList));
        }

        private void ViewArtists_Click(object sender, RoutedEventArgs e)
        {
            CatalogList.ItemsSource = _allCatalog;
            ItemCount = _allCatalog.Count;
            ArtistGroups = new ObservableCollection<IGrouping<string, CatalogItem>>(_allCatalog.GroupBy(c => c.Name[0].ToString()));
        }

        public class CatalogItem
        {
            public int ArtistId { get; set; }
            public string Name { get; set; }
            public List<AlbumItem> Albums { get; set; }
        }
        public class AlbumItem
        {
            public int AlbumId { get; set; }
            public string Title { get; set; }
            public List<TrackItem> Tracks { get; set; }
        }

        public class TrackItem
        {
            public int TrackId { get; set; }
            public string Name { get; set; }
            public string Genre { get; set; }
        }



        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
