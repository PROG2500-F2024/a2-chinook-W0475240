﻿using ChinookWPFApp.Models;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ChinookWPFApp
{
    public partial class AlbumsPage : Page, INotifyPropertyChanged
    {
        private readonly ChinookContext _context;
        private List<Album> _albums;

        public AlbumsPage()
        {
            _context = new ChinookContext();
            InitializeComponent();
            LoadAlbums();
        }

        public List<Album> Albums
        {
            get { return _albums; }
            set
            {
                _albums = value;
                OnPropertyChanged("Albums");
            }
        }

        private void LoadAlbums()
        {
            Albums = _context.Albums.ToList();
            DataContext = this;
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchTerm = SearchBox.Text.ToLower();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                Albums = _context.Albums.Where(a => a.Title.ToLower().Contains(searchTerm)).ToList();
            }
            else
            {
                Albums = _context.Albums.ToList();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
