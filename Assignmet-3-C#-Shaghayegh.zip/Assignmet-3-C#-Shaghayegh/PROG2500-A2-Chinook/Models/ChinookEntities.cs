﻿using ChinookWPFApp.Models;
using System.Data.Entity;

namespace ChinookWPFApp
{
    public partial class ChinookEntities : DbContext
    {
        public ChinookEntities() : base("name=ChinookEntities") { }

        public virtual DbSet<Album> Albums { get; set; }
        public virtual DbSet<Artist> Artists { get; set; }
        public virtual DbSet<Track> Tracks { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Album>()
                .HasMany(e => e.Tracks)
                .WithRequired(e => e.Album)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Artist>()
                .HasMany(e => e.Albums)
                .WithRequired(e => e.Artist)
                .WillCascadeOnDelete(false);
        }
    }
}
